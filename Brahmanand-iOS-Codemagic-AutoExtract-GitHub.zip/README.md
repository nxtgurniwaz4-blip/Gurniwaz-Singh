# Brahmanand iOS — Codemagic ZIP auto-extract

This repository layout intentionally keeps the reconstructed iOS project in a ZIP.

Required files at the GitHub repository root:

- `codemagic.yaml`
- `Podfile`
- `Brahmanand-iOS-Reconstructed.zip`

The Codemagic workflow first checks for an `.xcodeproj`. If it is not present, it automatically finds and extracts the ZIP, then runs CocoaPods and builds the IPA.

You can also extract the ZIP yourself and commit the Xcode project directly; the workflow supports both layouts.
