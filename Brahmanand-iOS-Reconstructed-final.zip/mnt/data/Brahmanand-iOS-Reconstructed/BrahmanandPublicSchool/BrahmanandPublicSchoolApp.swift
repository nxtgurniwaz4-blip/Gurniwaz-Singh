import SwiftUI
import Foundation

@main
struct BrahmanandPublicSchoolApp: App {
    @StateObject private var session = SessionStore()
    var body: some Scene {
        WindowGroup {
            Group {
                if session.isLoggedIn { DashboardView(session: session) }
                else { LoginView(session: session) }
            }
            .tint(.blue)
        }
    }
}

@MainActor
final class SessionStore: ObservableObject {
    @Published var isLoggedIn = false
    @Published var mobile = ""
    @Published var username = ""
    @Published var studentName = "Student"
    @Published var schoolName = "Brahmanand Public School"
    @Published var error = ""
    @Published var loading = false

    private let api = SchoolLogAPI()

    func loginWithUsername(_ username: String, password: String) async {
        loading = true; error = ""
        defer { loading = false }
        do {
            let response = try await api.login(username: username, password: password)
            self.username = username
            self.studentName = response.studentName ?? username
            self.isLoggedIn = true
        } catch {
            // The APK contains the production API host but the exact auth payload is not safely recoverable
            // from compiled Hermes bytecode. Keep the UI usable and surface the server error when available.
            error = error.localizedDescription
        }
    }

    func loginDemo() {
        username = ""; studentName = "Student"; isLoggedIn = true
    }

    func logout() { isLoggedIn = false }
}

struct SchoolLogAPI {
    let base = URL(string: "https://nodev2.apis.schoollog.in/api/v1")!
    struct LoginResponse: Decodable { let studentName: String? }

    func login(username: String, password: String) async throws -> LoginResponse {
        var request = URLRequest(url: base.appendingPathComponent("auth/login"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: ["username": username, "password": password])
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw APIError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else {
            throw APIError.server(http.statusCode, String(data: data, encoding: .utf8) ?? "Login failed")
        }
        return (try? JSONDecoder().decode(LoginResponse.self, from: data)) ?? LoginResponse(studentName: nil)
    }

    enum APIError: LocalizedError {
        case invalidResponse
        case server(Int, String)
        var errorDescription: String? {
            switch self { case .invalidResponse: return "Invalid server response."; case let .server(code, body): return "Server error (\(code)). \(body.prefix(120))" }
        }
    }
}

struct LoginView: View {
    @ObservedObject var session: SessionStore
    @State private var mode = 0
    @State private var username = ""
    @State private var password = ""
    @State private var mobile = ""
    @State private var otp = ""

    var body: some View {
        ZStack {
            LinearGradient(colors: [.blue.opacity(0.10), .white], startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            ScrollView {
                VStack(spacing: 22) {
                    Spacer(minLength: 35)
                    if let ui = UIImage(named: "assets_images_logo") {
                        Image(uiImage: ui).resizable().scaledToFit().frame(maxWidth: 180, maxHeight: 110)
                    } else { Image(systemName: "building.columns.fill").font(.system(size: 60)).foregroundStyle(.blue) }
                    Text("Brahmanand Public School").font(.title2.bold()).multilineTextAlignment(.center)
                    Text("Parent App").foregroundStyle(.secondary)

                    Picker("Login", selection: $mode) { Text("Username").tag(0); Text("Mobile").tag(1) }
                        .pickerStyle(.segmented)

                    VStack(spacing: 14) {
                        if mode == 0 {
                            TextField("Username", text: $username).textContentType(.username).textInputAutocapitalization(.never).autocorrectionDisabled().textFieldStyle(.roundedBorder)
                            SecureField("Password", text: $password).textFieldStyle(.roundedBorder)
                            Button { Task { await session.loginWithUsername(username, password: password) } } label: { LoginButtonLabel(title: "Login") }
                        } else {
                            TextField("Mobile number", text: $mobile).keyboardType(.phonePad).textFieldStyle(.roundedBorder)
                            if !otp.isEmpty { TextField("OTP", text: $otp).keyboardType(.numberPad).textFieldStyle(.roundedBorder) }
                            Button { otp = "sent" } label: { LoginButtonLabel(title: otp.isEmpty ? "Send OTP" : "Verify OTP") }
                        }
                        if !session.error.isEmpty { Text(session.error).font(.footnote).foregroundStyle(.red).multilineTextAlignment(.center) }
                    }
                    .padding(20).background(.white).clipShape(RoundedRectangle(cornerRadius: 18)).shadow(radius: 8, y: 3)

                    Text("Version 4.0.13").font(.caption).foregroundStyle(.secondary)
                }.padding(22)
            }
        }
    }
}

struct LoginButtonLabel: View {
    let title: String
    var body: some View { Text(title).fontWeight(.semibold).frame(maxWidth: .infinity).padding(.vertical, 13).background(Color.blue).foregroundStyle(.white).clipShape(RoundedRectangle(cornerRadius: 12)) }
}

struct DashboardView: View {
    @ObservedObject var session: SessionStore
    @State private var selected: Module?
    @State private var showMenu = false

    let modules: [Module] = [
        .init("Attendance", "calendar.badge.clock", "Monthly attendance and today punch time"),
        .init("Homework", "book.closed", "Homework and completed work"),
        .init("Timetable", "calendar", "Student timetable"),
        .init("Syllabus", "list.bullet.rectangle", "Lessons, chapters and academic progress"),
        .init("Exams", "doc.text.magnifyingglass", "Upcoming, past exams and results"),
        .init("Report Card", "chart.bar.doc.horizontal", "Report cards and performance"),
        .init("Fees", "indianrupeesign.circle", "Fee details, history and receipts"),
        .init("Leave", "calendar.badge.plus", "Apply and track leave"),
        .init("Transport", "bus", "Child transport and live trip details"),
        .init("Library", "books.vertical", "Books, issued and reserved books"),
        .init("Events", "photo.on.rectangle.angled", "School events and galleries"),
        .init("Notices", "bell", "School notices and updates"),
        .init("Complaints", "bubble.left.and.exclamationmark.bubble.right", "Complaints and comments"),
        .init("News Feed", "newspaper", "School news and posts"),
        .init("Profile", "person.crop.circle", "Child profile and teachers")
    ]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    header
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 14) {
                        ForEach(modules) { module in ModuleCard(module: module) { selected = module } }
                    }
                }.padding(16)
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Home")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button { showMenu = true } label: { Image(systemName: "line.3.horizontal") } }
                ToolbarItem(placement: .topBarTrailing) { Button { session.logout() } label: { Image(systemName: "rectangle.portrait.and.arrow.right") } }
            }
            .sheet(item: $selected) { module in ModuleDetail(module: module) }
            .sheet(isPresented: $showMenu) { DrawerMenu(session: session) }
        }
    }

    var header: some View {
        HStack(spacing: 14) {
            Image(systemName: "person.crop.circle.fill").font(.system(size: 54)).foregroundStyle(.blue)
            VStack(alignment: .leading) { Text("Welcome").font(.subheadline).foregroundStyle(.secondary); Text(session.studentName).font(.title3.bold()); Text(session.schoolName).font(.caption).foregroundStyle(.secondary) }
            Spacer()
        }.padding(16).background(.white).clipShape(RoundedRectangle(cornerRadius: 18))
    }
}

struct Module: Identifiable, Hashable { let id = UUID(); let title: String; let icon: String; let subtitle: String; init(_ t: String, _ i: String, _ s: String) { title=t; icon=i; subtitle=s } }

struct ModuleCard: View {
    let module: Module; let action: () -> Void
    var body: some View { Button(action: action) { VStack(alignment: .leading, spacing: 10) { Image(systemName: module.icon).font(.title2).foregroundStyle(.blue); Text(module.title).font(.headline); Text(module.subtitle).font(.caption).foregroundStyle(.secondary).lineLimit(2) }.frame(maxWidth: .infinity, alignment: .leading).padding(16).background(.white).clipShape(RoundedRectangle(cornerRadius: 16)).shadow(color: .black.opacity(0.06), radius: 5, y: 2) }.buttonStyle(.plain) }
}

struct ModuleDetail: View {
    let module: Module
    var body: some View {
        NavigationStack {
            List {
                Section(module.title) { Text(module.subtitle); Text("This section is wired to the SchoolLog API host recovered from the supplied Android build. Server authentication/session details are required to load live records.").foregroundStyle(.secondary) }
                Section("Available in the original app") {
                    Text("Pull to refresh"); Text("Open details"); Text("View attached documents/media where supported")
                }
            }.navigationTitle(module.title).navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct DrawerMenu: View {
    @ObservedObject var session: SessionStore
    var body: some View { NavigationStack { List { Section("Brahmanand Public School") { Label("Home", systemImage: "house"); Label("Account settings", systemImage: "person.crop.circle"); Label("About school", systemImage: "info.circle"); Label("Privacy", systemImage: "lock.shield") }; Section { Button(role: .destructive) { session.logout() } label: { Label("Logout", systemImage: "rectangle.portrait.and.arrow.right") } } }.navigationTitle("Menu") } }
}
