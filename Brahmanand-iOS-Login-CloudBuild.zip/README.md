# Brahmanand Public School — reconstructed iOS project

This project is a **native SwiftUI reconstruction** based on the supplied Android APK/decompiler archive.

Recovered from the APK:
- App name: Brahmanand Public School
- Android version: 4.0.13 / versionCode 413
- Original Android package: `in.robo.brahamanand.parentapp`
- Expo SDK: 53.0.0
- Hermes JavaScript bundle and Expo configuration
- Production SchoolLog API host: `https://nodev2.apis.schoollog.in/api/v1`
- Screens/routes visible in the compiled bundle, including attendance, homework, timetable, syllabus, exams, report card, fees, leave, transport, library, events, notices, complaints, news feed and child/profile areas
- A large set of original image assets from the APK

## What is implemented

The project now contains a real iOS SwiftUI app rather than the previous web placeholder. It has:
- Login UI with username/password and mobile/OTP modes
- Home dashboard with the major modules recovered from the APK
- Native navigation and module detail screens
- Drawer/account/logout UI
- Production API client scaffold
- Original extracted visual assets included in the Xcode project
- Portrait iPhone/iPad support
- Codemagic configuration for cloud builds

## Important limitation

The APK contains a compiled Hermes bytecode bundle rather than the original TypeScript/React Native source. Some exact request bodies, authentication/session handling, Firebase configuration, and platform-specific native behavior cannot be reconstructed with certainty from the APK alone. The UI and API surface have therefore been reconstructed conservatively instead of pretending that unavailable source code was recovered.

To make live data work, the authentication request must be matched to the current SchoolLog API contract. Once authenticated, the recovered endpoints can be wired screen-by-screen.

## Build

Open `BrahmanandPublicSchool.xcodeproj` on macOS/Xcode, select a signing team, then Archive. For a signed IPA, Codemagic also needs an Apple signing certificate/profile or App Store Connect credentials.
