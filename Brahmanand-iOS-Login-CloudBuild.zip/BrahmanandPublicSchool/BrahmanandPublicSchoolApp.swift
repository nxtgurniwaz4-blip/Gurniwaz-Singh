import SwiftUI
import Foundation

@main
struct BrahmanandPublicSchoolApp: App {
    @StateObject private var session = SessionStore()
    var body: some Scene {
        WindowGroup {
            Group {
                if session.isLoggedIn { DashboardView(session: session) }
                else { LoginView(session: session) }
            }
            .tint(.blue)
        }
    }
}

@MainActor
final class SessionStore: ObservableObject {
    @Published var isLoggedIn = false
    @Published var mobile = ""
    @Published var username = ""
    @Published var studentName = "Student"
    @Published var schoolName = "Brahmanand Public School"
    @Published var error = ""
    @Published var loading = false
    @Published var otpSent = false

    private let api = SchoolLogAPI()
    private let tokenKey = "schoollog.accessToken"

    init() {
        if let token = UserDefaults.standard.string(forKey: tokenKey), !token.isEmpty {
            isLoggedIn = true
        }
    }

    func loginWithUsername(_ username: String, password: String) async {
        guard !username.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              !password.isEmpty else { error = "Enter your username and password."; return }
        loading = true; error = ""
        defer { loading = false }
        do {
            let response = try await api.login(username: username, password: password)
            save(response: response, username: username)
        } catch { error = error.localizedDescription }
    }

    func sendOTP(_ mobile: String) async {
        let clean = mobile.filter(\.isNumber)
        guard clean.count >= 10 else { error = "Enter a valid mobile number."; return }
        loading = true; error = ""
        defer { loading = false }
        do {
            try await api.sendOTP(mobile: clean)
            self.mobile = clean
            otpSent = true
        } catch { error = error.localizedDescription }
    }

    func verifyOTP(_ otp: String) async {
        guard otp.count == 6 else { error = "Enter the 6 digit OTP."; return }
        loading = true; error = ""
        defer { loading = false }
        do {
            let response = try await api.verifyOTP(mobile: mobile, otp: otp)
            save(response: response, username: response.username ?? mobile)
        } catch { error = error.localizedDescription }
    }

    private func save(response: SchoolLogAPI.AuthResponse, username: String) {
        self.username = response.username ?? username
        self.studentName = response.studentName ?? username
        if let school = response.schoolName, !school.isEmpty { self.schoolName = school }
        if let token = response.accessToken, !token.isEmpty {
            UserDefaults.standard.set(token, forKey: tokenKey)
        }
        isLoggedIn = true
    }

    func logout() {
        UserDefaults.standard.removeObject(forKey: tokenKey)
        isLoggedIn = false
        otpSent = false
        error = ""
    }
}

struct SchoolLogAPI {
    let base = URL(string: "https://nodev2.apis.schoollog.in/api/v1")!

    struct AuthResponse: Decodable {
        let accessToken: String?
        let token: String?
        let studentName: String?
        let username: String?
        let schoolName: String?

        enum CodingKeys: String, CodingKey {
            case accessToken, token, studentName, username, schoolName
            case data, result
        }

        init(from decoder: Decoder) throws {
            let c = try decoder.container(keyedBy: CodingKeys.self)
            accessToken = try c.decodeIfPresent(String.self, forKey: .accessToken)
                ?? (try c.decodeIfPresent(String.self, forKey: .token))
            studentName = try c.decodeIfPresent(String.self, forKey: .studentName)
            username = try c.decodeIfPresent(String.self, forKey: .username)
            schoolName = try c.decodeIfPresent(String.self, forKey: .schoolName)
        }
    }

    init(accessToken: String?, token: String?, studentName: String?, username: String?, schoolName: String?) {
        self.accessToken = accessToken
        self.token = token
        self.studentName = studentName
        self.username = username
        self.schoolName = schoolName
    }

    private func request(_ path: String, body: [String: Any]) throws -> URLRequest {
        var r = URLRequest(url: base.appendingPathComponent(path))
        r.httpMethod = "POST"
        r.setValue("application/json", forHTTPHeaderField: "Content-Type")
        r.setValue("application/json", forHTTPHeaderField: "Accept")
        r.setValue("4.0.13", forHTTPHeaderField: "X-App-Version")
        r.httpBody = try JSONSerialization.data(withJSONObject: body)
        return r
    }

    private func post(_ paths: [String], bodies: [[String: Any]]) async throws -> (Data, HTTPURLResponse) {
        var last: Error = APIError.invalidResponse
        for path in paths {
            for body in bodies {
                do {
                    let r = try request(path, body: body)
                    let (data, response) = try await URLSession.shared.data(for: r)
                    guard let http = response as? HTTPURLResponse else { throw APIError.invalidResponse }
                    if (200..<300).contains(http.statusCode) { return (data, http) }
                    // Try the next known contract for 400/404/405; preserve server details if all fail.
                    last = APIError.server(http.statusCode, String(data: data, encoding: .utf8) ?? "Request failed")
                } catch { last = error }
            }
        }
        throw last
    }

    func login(username: String, password: String) async throws -> AuthResponse {
        // The APK exposes the SchoolLog production host and a username/password feature flag,
        // but Hermes compilation hides the original hook implementation. Try the compatible
        // parent-login contracts without asking the user for anything beyond their credentials.
        let (data, _) = try await post(
            ["auth/login", "login/parent-app", "login/parent-app-password", "auth/parent-login"],
            bodies: [
                ["username": username, "password": password],
                ["userName": username, "password": password],
                ["login": username, "password": password]
            ]
        )
        return try decodeAuth(data)
    }

    func sendOTP(mobile: String) async throws {
        // The original APK contains the public parent OTP verification route.
        let (_, _) = try await post(
            ["login/parent-app-otp-token/send-public", "login/parent-app-otp-token/send", "auth/send-otp"],
            bodies: [
                ["mobile": mobile],
                ["mobileNumber": mobile],
                ["phone": mobile]
            ]
        )
    }

    func verifyOTP(mobile: String, otp: String) async throws -> AuthResponse {
        let (data, _) = try await post(
            ["login/parent-app-otp-token/verify-public"],
            bodies: [
                ["mobile": mobile, "otp": otp],
                ["mobileNumber": mobile, "otp": otp],
                ["phone": mobile, "otp": otp]
            ]
        )
        return try decodeAuth(data)
    }

    private func decodeAuth(_ data: Data) throws -> AuthResponse {
        if let direct = try? JSONDecoder().decode(AuthResponse.self, from: data) { return direct }
        if let object = try JSONSerialization.jsonObject(with: data) as? [String: Any] {
            let candidates = [object, object["data"] as? [String: Any], object["result"] as? [String: Any]].compactMap { $0 }
            for o in candidates {
                let token = (o["accessToken"] as? String) ?? (o["token"] as? String) ?? (o["access_token"] as? String)
                let name = (o["studentName"] as? String) ?? (o["student_name"] as? String) ?? (o["name"] as? String)
                let user = (o["username"] as? String) ?? (o["userName"] as? String)
                let school = (o["schoolName"] as? String) ?? (o["school_name"] as? String)
                if token != nil || name != nil || user != nil { return AuthResponse(accessToken: token, token: nil, studentName: name, username: user, schoolName: school) }
            }
        }
        throw APIError.invalidResponse
    }

    enum APIError: LocalizedError {
        case invalidResponse
        case server(Int, String)
        var errorDescription: String? {
            switch self {
            case .invalidResponse: return "The SchoolLog server returned an unexpected response."
            case let .server(code, body): return "SchoolLog error (\(code)). \(body.prefix(180))"
            }
        }
    }
}

struct LoginView: View {
    @ObservedObject var session: SessionStore
    @State private var mode = 0
    @State private var username = ""
    @State private var password = ""
    @State private var mobile = ""
    @State private var otp = ""

    var body: some View {
        ZStack {
            LinearGradient(colors: [.blue.opacity(0.10), .white], startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            ScrollView {
                VStack(spacing: 22) {
                    Spacer(minLength: 35)
                    if let ui = UIImage(named: "assets_images_logo") {
                        Image(uiImage: ui).resizable().scaledToFit().frame(maxWidth: 180, maxHeight: 110)
                    } else { Image(systemName: "building.columns.fill").font(.system(size: 60)).foregroundStyle(.blue) }
                    Text("Brahmanand Public School").font(.title2.bold()).multilineTextAlignment(.center)
                    Text("Parent App").foregroundStyle(.secondary)

                    Picker("Login", selection: $mode) { Text("Username").tag(0); Text("Mobile OTP").tag(1) }
                        .pickerStyle(.segmented)

                    VStack(spacing: 14) {
                        if mode == 0 {
                            TextField("Username", text: $username).textContentType(.username).textInputAutocapitalization(.never).autocorrectionDisabled().textFieldStyle(.roundedBorder)
                            SecureField("Password", text: $password).textContentType(.password).textFieldStyle(.roundedBorder)
                            Button { Task { await session.loginWithUsername(username, password: password) } } label: { LoginButtonLabel(title: session.loading ? "Logging in…" : "Login") }.disabled(session.loading)
                        } else {
                            TextField("Mobile number", text: $mobile).keyboardType(.phonePad).textFieldStyle(.roundedBorder)
                            if session.otpSent {
                                TextField("6 digit OTP", text: $otp).keyboardType(.numberPad).textFieldStyle(.roundedBorder)
                                Button { Task { await session.verifyOTP(otp) } } label: { LoginButtonLabel(title: session.loading ? "Verifying…" : "Verify OTP") }.disabled(session.loading)
                                Button("Resend OTP") { Task { await session.sendOTP(mobile) } }.disabled(session.loading)
                            } else {
                                Button { Task { await session.sendOTP(mobile) } } label: { LoginButtonLabel(title: session.loading ? "Sending…" : "Send OTP") }.disabled(session.loading)
                            }
                        }
                        if !session.error.isEmpty { Text(session.error).font(.footnote).foregroundStyle(.red).multilineTextAlignment(.center) }
                    }
                    .padding(20).background(.white).clipShape(RoundedRectangle(cornerRadius: 18)).shadow(radius: 8, y: 3)
                    Text("Version 4.0.13").font(.caption).foregroundStyle(.secondary)
                }.padding(22)
            }
        }
    }
}

struct LoginButtonLabel: View {
    let title: String
    var body: some View { Text(title).fontWeight(.semibold).frame(maxWidth: .infinity).padding(.vertical, 13).background(Color.blue).foregroundStyle(.white).clipShape(RoundedRectangle(cornerRadius: 12)) }
}

struct DashboardView: View {
    @ObservedObject var session: SessionStore
    @State private var selected: Module?
    @State private var showMenu = false
    let modules: [Module] = [
        .init("Attendance", "calendar.badge.clock", "Monthly attendance and today punch time"), .init("Homework", "book.closed", "Homework and completed work"), .init("Timetable", "calendar", "Student timetable"), .init("Syllabus", "list.bullet.rectangle", "Lessons, chapters and academic progress"), .init("Exams", "doc.text.magnifyingglass", "Upcoming, past exams and results"), .init("Report Card", "chart.bar.doc.horizontal", "Report cards and performance"), .init("Fees", "indianrupeesign.circle", "Fee details, history and receipts"), .init("Leave", "calendar.badge.plus", "Apply and track leave"), .init("Transport", "bus", "Child transport and live trip details"), .init("Library", "books.vertical", "Books, issued and reserved books"), .init("Events", "photo.on.rectangle.angled", "School events and galleries"), .init("Notices", "bell", "School notices and updates"), .init("Complaints", "bubble.left.and.exclamationmark.bubble.right", "Complaints and comments"), .init("News Feed", "newspaper", "School news and posts"), .init("Profile", "person.crop.circle", "Child profile and teachers")
    ]
    var body: some View {
        NavigationStack { ScrollView { VStack(alignment: .leading, spacing: 18) { header; LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 14) { ForEach(modules) { module in ModuleCard(module: module) { selected = module } } } }.padding(16) }.background(Color(.systemGroupedBackground)).navigationTitle("Home").toolbar { ToolbarItem(placement: .topBarLeading) { Button { showMenu = true } label: { Image(systemName: "line.3.horizontal") } }; ToolbarItem(placement: .topBarTrailing) { Button { session.logout() } label: { Image(systemName: "rectangle.portrait.and.arrow.right") } } }.sheet(item: $selected) { module in ModuleDetail(module: module) }.sheet(isPresented: $showMenu) { DrawerMenu(session: session) } }
    }
    var header: some View { HStack(spacing: 14) { Image(systemName: "person.crop.circle.fill").font(.system(size: 54)).foregroundStyle(.blue); VStack(alignment: .leading) { Text("Welcome").font(.subheadline).foregroundStyle(.secondary); Text(session.studentName).font(.title3.bold()); Text(session.schoolName).font(.caption).foregroundStyle(.secondary) }; Spacer() }.padding(16).background(.white).clipShape(RoundedRectangle(cornerRadius: 18)) }
}

struct Module: Identifiable, Hashable { let id = UUID(); let title: String; let icon: String; let subtitle: String; init(_ t: String, _ i: String, _ s: String) { title=t; icon=i; subtitle=s } }
struct ModuleCard: View { let module: Module; let action: () -> Void; var body: some View { Button(action: action) { VStack(alignment: .leading, spacing: 10) { Image(systemName: module.icon).font(.title2).foregroundStyle(.blue); Text(module.title).font(.headline); Text(module.subtitle).font(.caption).foregroundStyle(.secondary).lineLimit(2) }.frame(maxWidth: .infinity, alignment: .leading).padding(16).background(.white).clipShape(RoundedRectangle(cornerRadius: 16)).shadow(color: .black.opacity(0.06), radius: 5, y: 2) }.buttonStyle(.plain) } }
struct ModuleDetail: View { let module: Module; var body: some View { NavigationStack { List { Section(module.title) { Text(module.subtitle); Text("Live records require a valid SchoolLog session.").foregroundStyle(.secondary) } }.navigationTitle(module.title).navigationBarTitleDisplayMode(.inline) } } }
struct DrawerMenu: View { @ObservedObject var session: SessionStore; var body: some View { NavigationStack { List { Section("Brahmanand Public School") { Label("Home", systemImage: "house"); Label("Account settings", systemImage: "person.crop.circle"); Label("About school", systemImage: "info.circle"); Label("Privacy", systemImage: "lock.shield") }; Section { Button(role: .destructive) { session.logout() } label: { Label("Logout", systemImage: "rectangle.portrait.and.arrow.right") } } }.navigationTitle("Menu") } } }
